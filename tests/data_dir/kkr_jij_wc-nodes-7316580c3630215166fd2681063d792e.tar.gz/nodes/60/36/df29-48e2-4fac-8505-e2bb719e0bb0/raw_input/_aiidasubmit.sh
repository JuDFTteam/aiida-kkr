#!/bin/bash
#SBATCH --no-requeue
#SBATCH --job-name="aiida-10442"
#SBATCH --get-user-env
#SBATCH --output=_scheduler-stdout.txt
#SBATCH --error=_scheduler-stderr.txt
#SBATCH --partition=oscar
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=12
#SBATCH --time=06:00:00


source compiler-select intel-fi
ulimit -s unlimited
export OMP_STACKSIZE=2G

'srun' '/local/th1/DFT/kkrhost_hybrid_3.5_intel.exe'  > 'out_kkr' 
