#!/bin/bash
exec > _scheduler-stdout.txt
exec 2> _scheduler-stderr.txt



ulimit -s hard
export OMP_STACKSIZE=2G
#source compiler-select gcc8

'/home/ruess/Home/JupyterHub/dev/opt/aiida-kkr/tests/jukkr/kkr.x'  > 'out_kkr' 
