#!/bin/bash
#SBATCH --no-requeue
#SBATCH --job-name="aiida-16341"
#SBATCH --get-user-env
#SBATCH --output=_scheduler-stdout.txt
#SBATCH --error=_scheduler-stderr.txt
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=48
#SBATCH --time=10:00:00
#SBATCH --account=jara0191

ulimit -s unlimited; export OMP_STACKSIZE=2g


ulimit -s unlimited
export OMP_STACKSIZE=2G

ulimit -s unlimited
export OMP_STACKSIZE=2G

'srun' '/work/jara0191/ck142666/aiida/code_assembly/kkrflex.exe'  > 'out_kkrimp' 
