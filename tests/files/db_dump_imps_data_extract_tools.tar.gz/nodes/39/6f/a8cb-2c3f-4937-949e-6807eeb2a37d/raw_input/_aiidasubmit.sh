#!/bin/bash
#SBATCH --no-requeue
#SBATCH --job-name="aiida-443695"
#SBATCH --get-user-env
#SBATCH --output=_scheduler-stdout.txt
#SBATCH --error=_scheduler-stderr.txt
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=48
#SBATCH --time=10:00:00
#SBATCH --account=jara0191

ulimit -s unlimited; export OMP_STACKSIZE=2g


'srun' '/work/pr357554/codes_aiida_install/kkr.x'  > 'out_kkr' 
