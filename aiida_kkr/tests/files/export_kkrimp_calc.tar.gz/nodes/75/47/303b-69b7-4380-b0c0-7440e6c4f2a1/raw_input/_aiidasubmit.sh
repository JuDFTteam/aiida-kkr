#!/bin/bash
#SBATCH --no-requeue
#SBATCH --job-name="aiida-420021"
#SBATCH --get-user-env
#SBATCH --output=_scheduler-stdout.txt
#SBATCH --error=_scheduler-stderr.txt
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=48
#SBATCH --time=1-00:00:00
#SBATCH --account=jara0191 
export OMP_NUM_THREADS=1; export OMP_STACKSIZE=2g


'srun' '/work/pr357554/codes_aiida_install/kkrflex.exe'  > 'out_kkrimp' 

rm kkrflex_green* kkrflex_tmat test*
