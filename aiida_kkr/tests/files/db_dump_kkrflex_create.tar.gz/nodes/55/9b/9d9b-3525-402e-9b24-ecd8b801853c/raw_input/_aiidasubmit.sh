#!/bin/bash
#PBS -r n
#PBS -m n
#PBS -N aiida-71
#PBS -V
#PBS -o _scheduler-stdout.txt
#PBS -e _scheduler-stderr.txt
#PBS -q th1_node
#PBS -l nodes=1:ppn=1
cd "$PBS_O_WORKDIR"


ln -s /local/th1/ruess/codes_aiida_install/ElementDataBase .

'mpirun' '-np' '1' '/local/th1/ruess/codes_aiida_install/voronoi.exe'  > 'out_voronoi' 
