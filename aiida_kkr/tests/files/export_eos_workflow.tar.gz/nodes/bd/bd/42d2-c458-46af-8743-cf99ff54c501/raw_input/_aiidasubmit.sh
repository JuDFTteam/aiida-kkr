#!/bin/bash
#PBS -r n
#PBS -m n
#PBS -N aiida-60491
#PBS -V
#PBS -o _scheduler-stdout.txt
#PBS -e _scheduler-stderr.txt
#PBS -q th1
#PBS -l nodes=1:ppn=12,walltime=03:00:00
cd "$PBS_O_WORKDIR"


ln -s /local/th1/ruess/codes_aiida_install/ElementDataBase .

'/local/th1/ruess/codes_aiida_install/voronoi.exe'  > 'out_voronoi' 
