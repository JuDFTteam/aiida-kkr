#!/bin/bash
exec > _scheduler-stdout.txt
exec 2> _scheduler-stderr.txt


source compiler-select intel
ulimit -s unlimited
export OMP_STACKSIZE=2G

'/Local/aiida_codes/kkr.x'  > 'out_kkr' 
