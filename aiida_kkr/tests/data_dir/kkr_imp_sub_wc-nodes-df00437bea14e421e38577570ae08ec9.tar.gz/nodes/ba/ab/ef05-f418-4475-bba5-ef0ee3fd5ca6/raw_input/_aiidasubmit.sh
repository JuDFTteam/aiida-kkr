#!/bin/bash
exec > _scheduler-stdout.txt
exec 2> _scheduler-stderr.txt


'/Users/ruess/Desktop/Rechnungen/Sourcecodes/aiida/aiida-kkr/aiida_kkr/tests/jukkr/kkr.x'  > 'out_kkr' 
