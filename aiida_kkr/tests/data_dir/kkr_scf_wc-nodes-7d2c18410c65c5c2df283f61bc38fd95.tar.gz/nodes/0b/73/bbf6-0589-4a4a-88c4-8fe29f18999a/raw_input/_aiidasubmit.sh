#!/bin/bash
exec > _scheduler-stdout.txt
exec 2> _scheduler-stderr.txt



ulimit -s hard
ln -s /Users/ruess/sourcecodes/aiida/aiida-kkr/aiida_kkr/tests/jukkr/ElementDataBase .
    

'/Users/ruess/sourcecodes/aiida/aiida-kkr/aiida_kkr/tests/jukkr/voronoi.exe'  > 'out_voronoi' 
