#!/bin/bash
exec > _scheduler-stdout.txt
exec 2> _scheduler-stderr.txt



ulimit -s hard
export OMP_STACKSIZE=2G
source compiler-select intel

'/Users/ruess/sourcecodes/aiida/aiida-kkr/aiida_kkr/tests/jukkr/kkrflex.exe'  > 'out_kkrimp' 
